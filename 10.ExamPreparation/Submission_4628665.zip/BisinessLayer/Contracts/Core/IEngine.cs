﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecyclingStation.BisinessLayer.Contracts.Core
{
    public interface IEngine
    {
        void Run();
    }
}
